#!/data/data/com.termux/files/usr/bin/bash
# shellcheck shell=bash

export TERMUX_PREFIX="/data/data/com.termux/files/usr"
export TERMUX_PACKAGE_ARCH="aarch64"

TERMUX__USER_ID___N="TERMUX__USER_ID"
TERMUX__USER_ID="${!TERMUX__USER_ID___N:-}"

function log() { echo "[*]" "$@"; }
function log_error() { echo "[*]" "$@" 1>&2; }

show_help() {
    cat <<'HELP_EOF'
termux-bootstrap-second-stage.sh runs the second stage of Termux
bootstrap installation.

Usage:
  termux-bootstrap-second-stage.sh

Available command_options:
  [ -h | --help ]    Display this help screen.
HELP_EOF
}

main() {
    if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
        show_help
        return 0
    else
        run_bootstrap_second_stage "$@"
        return $?
    fi
}

run_bootstrap_second_stage() {
    # Ensure only Termux UID runs
    ensure_running_with_termux_uid || return $?

    # Lock file to prevent multiple runs
    local lock_file="$TERMUX_PREFIX/etc/termux/termux-bootstrap/second-stage/termux-bootstrap-second-stage.sh.lock"
    local output
    output="$(ln -s "termux-bootstrap-second-stage.sh" "$lock_file" 2>&1)"
    local return_value=$?
    if [ $return_value -ne 0 ]; then
        if [ $return_value -eq 1 ] && [[ "$output" == *"File exists"* ]]; then
            log "Second stage already run. To force, delete '$lock_file'."
            return 0
        else
            log_error "$output"
            return $return_value
        fi
    fi

    log "Running termux bootstrap second stage"
    run_bootstrap_second_stage_inner
    return_value=$?
    if [ $return_value -ne 0 ]; then
        log_error "Second stage failed"
        return $return_value
    fi

    log "Second stage completed successfully"
    return 0
}

run_bootstrap_second_stage_inner() {
    log "Running post-install scripts with pacman → apt fallback"
    run_postinst_with_fallback "pacman" "apt"
    return $?
}

run_postinst_with_fallback() {
    local mgr_primary=$1
    local mgr_fallback=$2

    export TERMUX_PACKAGE_MANAGER="$mgr_primary"
    run_package_postinst_maintainer_scripts
    local ret=$?
    if [ $ret -ne 0 ]; then
        log_error "$mgr_primary post_install scripts failed"
        log "Falling back to $mgr_fallback..."
        export TERMUX_PACKAGE_MANAGER="$mgr_fallback"
        run_package_postinst_maintainer_scripts
        ret=$?
        if [ $ret -ne 0 ]; then
            log_error "$mgr_fallback post_install scripts failed"
        fi
    fi
    return $ret
}

run_package_postinst_maintainer_scripts() {
    local package_dir script_path package_dir_basename package_version_pkgver package_version_pkgrel package_version

    if [ "${TERMUX_PACKAGE_MANAGER}" = "apt" ]; then
        # Run APT postinst scripts
        if [ -d "${TERMUX_PREFIX}/var/lib/dpkg/info" ]; then
            for script_path in "${TERMUX_PREFIX}/var/lib/dpkg/info/"*.postinst; do
                [ -e "$script_path" ] || continue
                chmod u+x "$script_path" || return $?
                local package_name="${script_path##*/}"
                package_name="${package_name::-9}"
                log "Running APT postinst for '$package_name'"
                (
                    cd / || exit $?
                    export DPKG_MAINTSCRIPT_PACKAGE="$package_name"
                    export DPKG_MAINTSCRIPT_ARCH="$TERMUX_PACKAGE_ARCH"
                    export DPKG_MAINTSCRIPT_NAME="postinst"
                    "$script_path" configure || { log_error "Failed $package_name postinst"; exit $?; }
                ) || return $?
            done
        fi
    elif [ "${TERMUX_PACKAGE_MANAGER}" = "pacman" ]; then
        # Run pacman post_install scripts
        if [ -d "${TERMUX_PREFIX}/var/lib/pacman/local" ]; then
            for script_path in "${TERMUX_PREFIX}/var/lib/pacman/local/"*/install; do
                [ -e "$script_path" ] || continue
                package_dir="${script_path::-8}"
                package_dir_basename="${package_dir##*/}"

                # Parse version: pkgver-pkgrel
                package_version_pkgrel="${package_dir_basename##*-}"
                package_name_and_version_pkgver="${package_dir_basename%"$package_version_pkgrel"}"
                package_name_and_version_pkgver="${package_name_and_version_pkgver%?}"
                package_version_pkgver="${package_name_and_version_pkgver##*-}"
                package_version="$package_version_pkgver-$package_version_pkgrel"

                if [[ ! "$package_version" =~ ^([0-9]+:)?[^-]+-[^-]+$ ]]; then
                    log_error "Invalid package_version '$package_version'"
                    return 1
                fi

                log "Running pacman post_install for '$package_dir_basename'"
                (
                    cd / || exit $?
                    unset -f post_install || exit $?
                    source "$script_path" || { log_error "Failed sourcing $package_dir_basename"; exit $?; }
                    if [[ "$(type -t post_install 2>/dev/null)" == "function" ]]; then
                        post_install "$package_version" || { log_error "Failed post_install $package_dir_basename"; exit $?; }
                    fi
                ) || return $?
            done
        fi
    else
        log_error "Unknown TERMUX_PACKAGE_MANAGER: $TERMUX_PACKAGE_MANAGER"
        return 1
    fi

    return 0
}

# Execute main
main "$@"
