#!/data/data/com.termux/files/usr/bin/bash
# Alpine bootstrap second stage for Termux (proot-based)

export TERMUX_PREFIX="${TERMUX_PREFIX:-/data/data/com.termux/files/usr}"
export TERMUX_PACKAGE_MANAGER="apk"
export TERMUX_PACKAGE_ARCH="aarch64"

# Disable Termux LD_PRELOAD to avoid preload conflicts
unset LD_PRELOAD

# proot wrapper for apk
APK_BIN="proot -r ${TERMUX_PREFIX} /sbin/apk"

function log() { echo "[*]" "$@"; }
function log_error() { echo "[!] ERROR:" "$@" 1>&2; }

show_help() {
    cat <<'HELP_EOF'
Alpine bootstrap second stage for Termux.

Usage:
  termux-bootstrap-second-stage.sh

This script initializes Alpine's apk database inside the Termux rootfs,
installs base packages, and runs apk fix. All apk calls are routed
through proot to simulate root privileges.
HELP_EOF
}

main() {
    if [ "$1" = "-h" ] || [ "$1" = "--help" ]; then
        show_help
        return 0
    fi
    run_bootstrap_second_stage "$@"
}

run_bootstrap_second_stage() {
    local output
    output="$(ln -s "termux-bootstrap-second-stage.sh" \
        "${TERMUX_PREFIX}/etc/termux/termux-bootstrap/second-stage/termux-bootstrap-second-stage.sh.lock" 2>&1)"
    if [ $? -ne 0 ]; then
        if [[ "$output" == *"File exists"* ]]; then
            log "The Alpine bootstrap second stage has already been run before and cannot be run again."
            log "Delete the lock file manually if you want to force re-run."
            return 0
        else
            log_error "$output"
            log_error "Failed to create lock file"
            return 1
        fi
    fi

    log "Running Alpine bootstrap second stage"
    run_bootstrap_second_stage_inner
    if [ $? -ne 0 ]; then
        log_error "Failed to run Alpine bootstrap second stage"
        return 1
    fi

    log "Alpine bootstrap second stage completed successfully"
    return 0
}

run_bootstrap_second_stage_inner() {
    log "Initializing Alpine package manager"

    # Ensure apk database exists
    if [ ! -d "${TERMUX_PREFIX}/var/lib/apk" ]; then
        mkdir -p "${TERMUX_PREFIX}/var/lib/apk"
        $APK_BIN --initdb add alpine-base || return $?
#--root "${TERMUX_PREFIX}" 
#--initdb add alpine-base || return $?
    fi

    # Repair/configure packages
   # $APK_BIN add fix || return $?
    $APK_BIN fix || return $?
#--root "${TERMUX_PREFIX}" 
#fix || return $?

    # Ensure base utilities are present
    $APK_BIN add --no-cache bash coreutils || return $?
#--root "${TERMUX_PREFIX}" 
#add --no-cache bash coreutils || return $?

    return 0
}

main "$@"
