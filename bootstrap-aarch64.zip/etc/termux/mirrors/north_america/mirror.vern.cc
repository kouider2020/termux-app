# This file is sourced by pkg
# Mirror by vern.cc
WEIGHT=1
MAIN="https://mirror.vern.cc/termux/termux-main"
ROOT="https://mirror.vern.cc/termux/termux-root"
X11="https://mirror.vern.cc/termux/termux-x11"
